/* Rupes rubiks cube */
import java.awt.*;
import java.util.*;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Event;
import java.io.StreamTokenizer;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;

public class Rubik extends Applet {
     Frame window;
//     MyPanel controlPanel = new MyPanel();
     ThreeD cubePanel = new ThreeD();
     int i=1;

     public void init() {
 /*         controlPanel.setLayout(new GridLayout(5,5));

          controlPanel.add(new Button("nine"));
          controlPanel.add(new Button("eight"));
           controlPanel.add(new Button("seven"));
          controlPanel.add(new Button("ten"));
          controlPanel.add(new Button());
          controlPanel.add(new Button("six"));
          controlPanel.add(new Button("elev"));
          controlPanel.add(new Button());
          controlPanel.add(new Button("five"));
          controlPanel.add(new Button("twelve"));
          controlPanel.add(new Button());
          controlPanel.add(new Button("four"));
         controlPanel.add(new Button("one"));
          controlPanel.add(new Button("two"));
          controlPanel.add(new Button("three"));
          */         
cubePanel.init();       
try {cubePanel.run(new URL(getDocumentBase(),"Rubik.class"));}
          catch(Exception e){}
       //   add (controlPanel);
          add (cubePanel);
          System.out.println("Initialized...");

	    
     }

/*    public boolean action(Event e, Object arg)  {
        if (e.target instanceof Button) {
             String label=(String)arg;
             System.out.println(" Button: "+label);
             if(label=="one") cubePanel.move(1);
             if(label=="two")                        cubePanel.move(2);
             if(label=="three")                        cubePanel.move(3);
             if(label=="four")                        cubePanel.move(4);
             if(label=="five")                        cubePanel.move(5);
             if(label=="six")                        cubePanel.move(6);
             if(label=="seven")                        cubePanel.move(7);
             if(label=="eight")                        cubePanel.move(8);
             if(label=="nine")                        cubePanel.move(9);
             if(label=="ten")                        cubePanel.move(10);
             if(label=="elev")                        cubePanel.move(11);
             if(label=="twelve")    cubePanel.move(12);
}
        return(true);
}*/



     public void destroy() {
          System.exit(0);
     }
     public Dimension preferredSize() {
          return new Dimension(200,200);
     }
    public void paint(Graphics g)
    {
	    g.drawString("Copyright 1996 Rupert Brooks", 21, size().height-25);
	    g.drawString("   Rubik's Cube V1.0 beta", 30, size().height-10);
          return;
    }

}

/* class MyPanel extends Panel {
     public void paint(Graphics g) {
          Dimension d = size();
          g.drawRect(0,0,d.width-1,d.height - 1);
     }
     public Insets insets() {
          return new Insets(5,5,5,5);
     }
     public Dimension preferredSize() {
         return new Dimension(250,150);
     }
     
}*/
     
         

