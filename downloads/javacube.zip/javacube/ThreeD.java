/* A set of classes to parse, represent and display 3D wireframe models
   represented in Wavefront .obj format. */
// So, as you can see, I just extended this from one of the tutorials


import java.awt.*;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Event;
import java.io.StreamTokenizer;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;

class FileFormatException extends Exception {
    public FileFormatException(String s) {
	super(s);
    }
}

/** The representation of a 3D model */
class Model3D {
      int cubes[]=new int[8];
    float cube[];
    int tnormals[],faces[],squares[],cols[];
    boolean transformed;
    Matrix3D mat[];
    Matrix3D overall;
    int i,j,k;  // counters

    Color colors[];
    float xmin, xmax, ymin, ymax, zmin, zmax;

    Model3D () {
	cubes[0]=0;          // these are the corner cubes -
	cubes[1]=2;          // used when finding the bounding box
	cubes[2]=6;
	cubes[3]=8;
	cubes[4]=18;
	cubes[5]=20;
	cubes[6]=24;
	cubes[7]=26;
	overall = new Matrix3D();
	mat = new Matrix3D[27];
	
	for(i=0;i<27;i++) {
	    mat[i]=new Matrix3D();
	}
	initMatrices(mat);
	cube=new float[24];
	cube[0]=0; cube[1]=0; cube[2]=0;
	cube[3]=10; cube[4]=0; cube[5]=0;
	cube[6]=0; cube[7]=10; cube[8]=0;
	cube[9]=10; cube[10]=10; cube[11]=0;
	cube[12]=0; cube[13]=0; cube[14]=10;
	cube[15]=10; cube[16]=0; cube[17]=10;
	cube[18]=0; cube[19]=10; cube[20]=10;
	cube[21]=10; cube[22]=10; cube[23]=10;
	faces = new int[24];
	faces[0]=0; faces[1]=4; faces[2]=5; faces[3]=1;
	faces[4]=0; faces[5]=2; faces[6]=6; faces[7]=4;
	faces[8]=2; faces[9]=3; faces[10]=7; faces[11]=6;
	faces[12]=3; faces[13]=1; faces[14]=5; faces[15]=7;
	faces[16]=3; faces[17]=2; faces[18]=0; faces[19]=1;
	faces[20]=4; faces[21]=6; faces[22]=7; faces[23]=5;
	
	colors = new Color[6];
        colors[0] = new Color(255,255,0);
        colors[1] = new Color(255,255,255);
        colors[2] = new Color(255,150,0);
        colors[3] = new Color(255,0,0);
        colors[4] = new Color(0,200,50);
        colors[5] = new Color(0,0,255);
	tnormals = new int[54];
	squares = new int[108];
 squares[0]=0 ; squares[1]=0 ; squares[2]=0 ; squares[3]=1 ; squares[4]=1 ;
 squares[5]=2 ; squares[6]=2 ; squares[7]=2 ; squares[8]=3 ; squares[9]=3 ;
 squares[10]=4 ; squares[11]=5 ; squares[12]=5 ; squares[13]=6 ; squares[14]=6 ;
 squares[15]=6 ; squares[16]=7 ; squares[17]=7 ; squares[18]=8 ; squares[19]=8 ;
 squares[20]=8 ; squares[21]=9 ; squares[22]=9 ; squares[23]=10 ; squares[24]=11 ;
 squares[25]=11 ; squares[26]=12 ; squares[27]=14 ; squares[28]=15 ; squares[29]=15  ;
 squares[30]=16 ; squares[31]=17 ; squares[32]=17 ; squares[33]=18 ; squares[34]=18 ;
 squares[35]=18 ; squares[36]=19 ; squares[37]=19 ; squares[38]=20 ; squares[39]=20 ;
 squares[40]=20 ; squares[41]=21 ; squares[42]=21 ; squares[43]=22 ; squares[44]=23 ;
 squares[45]=23 ; squares[46]=24 ; squares[47]=24 ; squares[48]=24 ; squares[49]=25 ;
 squares[50]=25 ; squares[51]=26 ; squares[52]=26 ; squares[53]=26 ; squares[54]= 0 ;
 squares[55]=1 ; squares[56]=4 ; squares[57]=0 ; squares[58]=4 ; squares[59]=0 ;
 squares[60]=3 ; squares[61]=4 ; squares[62]=1 ; squares[63]=4 ; squares[64]=4 ;
 squares[65]=3 ; squares[66]=4 ; squares[67]=1 ; squares[68]=2 ; squares[69]=4 ;
 squares[70]=2 ; squares[71]=4 ; squares[72]=2 ; squares[73]=3 ; squares[74]=4 ;
 squares[75]=0 ; squares[76]=1 ; squares[77]=0 ; squares[78]=0 ; squares[79]=3 ;
 squares[80]=1 ; squares[81]=3 ; squares[82]=1 ; squares[83]=2 ; squares[84]=2 ;
 squares[85]=2 ; squares[86]=3 ; squares[87]=0 ; squares[88]=1 ; squares[89]=5 ;
 squares[90]=0 ; squares[91]=5 ; squares[92]=0 ; squares[93]=3 ; squares[94]=5 ;
 squares[95]=1 ; squares[96]=5 ; squares[97]=5 ; squares[98]=3 ; squares[99]=5 ;
 squares[100]=1 ; squares[101]=2 ; squares[102]=5 ; squares[103]=2 ; squares[104]=5 ;
 squares[105]=2 ; squares[106]=3 ; squares[107]=5;
         cols=new int[54];
         for(i=0;i<54;i++){cols[i]=squares[i+54];}
    }
    /** Create a 3D model by parsing an input stream */
   // this is left here for future expansion to having a save routine
    Model3D (InputStream is) throws IOException, FileFormatException {
	this();
    }

    void initMatrices(Matrix3D mat[])
       {
      	for(i=0;i<3;i++) {
	      	for(j=0;j<3;j++) {
		      	for(k=0;k<3;k++) {
                            mat[i*9+j*3+k].unit();
                            mat[i*9+j*3+k].translate((float)k*10-15f,(float)j*10-15f,(float)i*10-15f);
                        }
                   }
            }
        return;}


    void paint(Graphics g) {
      // System.out.println("Model3D: paint");
      float pts[] = new float[12];
      int tpts[] = new int[12];
      int xpts[] = new int[4];
      int ypts[] = new int[4];
      int index, q, qq, qqq;
//	transform();
      float v[]=new float[12];
      int v1[]=new int[12];
      int counter;
      for (counter=0; counter<54;counter++)
      {
          for (int yy=0; yy<4;yy++)
            {
            for(int zz=0; zz<3; zz++)
               {
	      	v[yy*3+zz]=cube[faces[squares[counter+54]*4+yy]*3+zz];
               }
            }
      	mat[squares[counter]].transform(v, v1, 4);
            for (int yy=0; yy<12; yy++)
               {v[yy]=(float)v1[yy];}
      	overall.transform(v, v1, 4);
            
            tnormals[counter]=(v1[4]-v1[1])*(v1[6]-v1[0])-(v1[3]-v1[0])*(v1[7]-v1[1]);

//          for (q=0;q<54;q++){
              if (tnormals[counter]>0)
                   {                   

 
                   for (qqq=0;qqq<4;qqq++) {
                       xpts[qqq]=v1[qqq*3];
                       ypts[qqq]=v1[qqq*3+1];
    //              System.out.println("X("+qqq+")="+xpts[qqq]+" Y("+qqq+")="+ypts[qqq]+")");
                   }
  //                 System.out.println("Drawing...");


                   g.setColor(colors[cols[counter]]);
                   g.fillPolygon(xpts,ypts,4);
                    g.setColor(new Color(0,0,0));
                  for (qqq=0;qqq<4;qqq++) {
                       g.drawLine(xpts[qqq],ypts[qqq],xpts[(qqq+1)%4],ypts[(qqq+1)%4]);
                   }
             }
             
         }	
   }

/* switch colors */
public void move(int face1, int face2,ThreeD g)
   {
//   System.out.println("Now in move routine...Faces are "+face1+" "+face2);
   boolean test[]=new boolean[3];
   float fv[]=new float[12];
   int facev1[]=new int[12];
   int facev2[]=new int[12];
   int workArray[]=new int[24];
   int addThisOne, rotateDir,seekFace,dir;
   int countDiffPoints[]=new int[3];
   int directions[]=new int[3];
   for (i=0;i<3;countDiffPoints[i++]=0);
   for (i=0;i<3;test[i++]=false);
// Get faces
   for (i=0;i<4;i++)
       {
       for(j=0;j<3;j++)
           {
           fv[i*3+j]=cube[faces[squares[face1+54]*4+i]*3+j];
           }
       }
   mat[squares[face1]].transform(fv,facev1,4);
   for (i=0;i<4;i++)
       {
       for(j=0;j<3;j++)
           {
           fv[i*3+j]=cube[faces[squares[face2+54]*4+i]*3+j];
           }
       }
   mat[squares[face2]].transform(fv,facev2,4);
   for (i=0;i<12;i++)
      {
      workArray[i]=facev1[i];
      workArray[i+12]=facev2[i];
      }
   rotateDir=0;
   for (i=0;i<8;i++)
      {
      for(k=0;k<3;k++)
          {
          addThisOne=1;
          for(j=0; j<i;j++)
              {
              if (workArray[i*3+k]==workArray[j*3+k]) {addThisOne=0;}
              }
          // System.out.print("("+i+","+k+") "+workArray[i*3+k]+" ");
          countDiffPoints[k]+=addThisOne;
          }
       // System.out.println();
       }
//   System.out.println("Counts:  X: "+countDiffPoints[0]+" Y: "+countDiffPoints[1]+" Z: "+countDiffPoints[2]);
   for(i=0;i<3;i++)   // Get which direction the rotation is in
      {
      if (countDiffPoints[i]>2) {directions[2]=i;test[0]=!test[0];}
      if(countDiffPoints[i]==1) {directions[0]=i;test[1]=!test[1];}
      if(countDiffPoints[i]==2) {directions[1]=i;test[2]=!test[2];}
      }
   if (!(test[0]&&test[1]&&test[2]))return;
   for (i=0;i<8;i++)
      {
      if (workArray[i*3+directions[2]]>workArray[rotateDir*3+directions[2]]) rotateDir=i;
//      System.out.println("Selecting direction: "+workArray[i*3+directions[2]]);
      }
   if(rotateDir<4) {rotateDir=0;}
   else {rotateDir=1;}
   dir=rotateDir;
   int tmp=squares[face1+54];
   if (tmp==2||tmp==4||(tmp==3&&directions[2]==2)||(tmp==1&&directions[2]==1)) dir=(rotateDir+1)%2;
 //  System.out.println("Final Dir Value : "+rotateDir+" directions[2] "+directions[2]);
   seekFace=directions[2];
   workArray[0]=squares[face1];
   // System.out.print("Cubes 0: "+workArray[0]+" ");
   for (i=1;i<8;i++)
      {
      workArray[i]=getNextCube(workArray[i-1],seekFace,rotateDir);
      if (workArray[i]==-1) {
           if (seekFace==directions[2]) {seekFace=directions[0];}
           else {seekFace=directions[2];}
           workArray[i]=getNextCube(workArray[i-1],seekFace,rotateDir);
           if (workArray[i]==-1) {
                rotateDir=(rotateDir+1)%2;
                workArray[i]=getNextCube(workArray[i-1],seekFace,rotateDir);
           }
       }      
//       System.out.print(i+": "+workArray[i]+" ");
    }
    workArray[8]=getMiddleCube(directions[1],workArray);
    // System.out.println(" middle: "+workArray[8]);
    rotate(workArray,dir,directions[1],g);
    
    
      
return;}  
   


   void rotate(int cubes[],int dir,int axis,ThreeD g)
      {
//      System.out.println("Entering rotate... dir= "+dir);
      int steps=5;
      if(dir==0)dir=-1;
      float rotationStep=(float)dir*90f/(float)steps;
      Graphics gr=g.getGraphics();

      int start=0;
    int workArray[]=new int[3];
    int sideFaces[]=new int[12];
    int endFaces[]=new int[9];
    int countEnds=0,countSides=0,tempCount=0;
    i=getCubeColors(cubes[0],workArray);
    if (i==3||(i==2&&cubes[8]==-1))start++;
    for (i=start;i<8+start;i++)
       {
       j=getCubeColors(cubes[i%8],workArray);
//       System.out.println("I: "+i+"J: "+j+" Counts, sides,ends "+countSides+" "+countEnds);
       for(k=0;k<j;k++)
          {
//          System.out.println("Checking "+workArray[k]);
          if ((i-start)%2==0) 
              {
//              System.out.println("Checking first square..");
              if (onAxis(squares[workArray[k]+54],axis))
                 {
                 endFaces[countEnds++]=workArray[k];
                 }
              else
                 {
                 sideFaces[countSides++]=workArray[k];
                 }
              }
           else
              {
              if (onAxis(squares[workArray[k]+54],axis))
                 {
                 endFaces[countEnds++]=workArray[k];
                 }
              else
                 {
//                 System.out.println("In Check: "+workArray[k]+" "+squares[workArray[k]+54]+" "+sideFaces[countSides-1]);
                 if(squares[workArray[k]+54]==squares[sideFaces[countSides-1]+54])
                     {
 //                    System.out.println("Adding "+workArray[k]);
                     sideFaces[countSides]=workArray[k];
                     tempCount++;
                     }
                 else
                     {
  //                   System.out.println("Adding "+workArray[k]+" going around corner.");
                     sideFaces[countSides+1]=workArray[k];
                     tempCount++;
                     }
                 }
              }
           }
           countSides+=tempCount;
           tempCount=0;
        }
//    System.out.println("Colors found.. "+countSides+" on the sides and on the end "+countEnds);

      switch (axis){
         case 0: {
            for(i=0;i<steps;i++)
              {
              for(j=0;j<8;j++)
                  {
                  mat[cubes[j]].xrot(rotationStep);      
                  }
              if(cubes[8]!=-1) mat[cubes[8]].xrot(rotationStep);
              g.update(gr);
 //       System.out.println("Repainting...");
           }
           break;}
      case 1: {
      for(i=0;i<steps;i++)
        {
        for(j=0;j<8;j++)
            {
            mat[cubes[j]].yrot(rotationStep);      
            }
        if(cubes[8]!=-1) mat[cubes[8]].yrot(rotationStep);
        g.update(gr);
 //       System.out.println("Repainting...");
        }
        break;}
      case 2: {
      for(i=0;i<steps;i++)
        {
        for(j=0;j<8;j++)
            {
            mat[cubes[j]].zrot(rotationStep);      
            }
        if(cubes[8]!=-1) mat[cubes[8]].zrot(rotationStep);
        g.update(gr);
   //     System.out.println("Repainting...");
        }
        break;}
      }
    
//    for (i=0;i<12;i++)
//      {
//      System.out.println(" : "+sideFaces[i]+" "+squares[sideFaces[i]]);
//      }
    int tempColors[]=new int[3];
    tempColors[0]=cols[sideFaces[0]];
    tempColors[1]=cols[sideFaces[1]];
    tempColors[2]=cols[sideFaces[2]];
    for(i=0;i<9;i++)
       {
       cols[sideFaces[i]]=cols[sideFaces[i+3]];
       }
    cols[sideFaces[9]]=tempColors[0];
    cols[sideFaces[10]]=tempColors[1];
    cols[sideFaces[11]]=tempColors[2];
    if (countEnds>0) {
       tempColors[0]=cols[endFaces[0]];
       tempColors[1]=cols[endFaces[1]];
       for(i=0;i<6;i++)
          {
          cols[endFaces[i]]=cols[endFaces[i+2]];
          }
       cols[endFaces[6]]=tempColors[0];
       cols[endFaces[7]]=tempColors[1];
    }
    initMatrices(mat);
        g.update(gr);
    return;
   }

   boolean onAxis(int face, int axis)
      {
      boolean returnVal=false;
      if (axis==0&&(face==1||face==3))returnVal=true;
      if (axis==1&&(face==0||face==2))returnVal=true;
      if (axis==2&&(face==4||face==5))returnVal=true;
      return returnVal;
      }

   int getCubeColors(int cube,int cubeFaces[])
       {
       int q,count=0;
       for(q=0;q<3;q++) {cubeFaces[q]=-1;}
       for (q=0;q<54;q++)
          {
          if (squares[q]==cube) 
              {cubeFaces[count++]=q;
               if(count==3)q=54;}
          }
       return count;
       }

   int getMiddleCube(int zeroAxis, int cubes[])
       {
       int returnVal=0,highCube=0;
       for(i=0;i<8;i++) {
          if(cubes[i]==4||cubes[i]==14)returnVal=-1;
          if(cubes[i]==26)highCube=1;
          }
       if (returnVal==-1) return returnVal;
       switch (zeroAxis) {
           case 0: {
                   if (highCube==1) {returnVal=14;}
                   else {returnVal=12;}
                   break;}
           case 1: {
                   if (highCube==1) {returnVal=16;}
                   else {returnVal=10;}
                   break;}
           case 2: {
                   if (highCube==1) {returnVal=22;}
                   else {returnVal=4;}
                   break;}
           }
       

//System.out.println();
//System.out.println("In getMiddleCube: Given: "+zeroIndex+" Which is: "+squares[54+face]+" Returning: "+returnVal);
return returnVal;   
       }
/* Return the next cube in a particular direction, or -1 if at edge */
   int getNextCube(int cube, int dir, int polarity)
   {
      int returnVal=-1;
      switch (polarity){
         case 0:{
                switch(dir){
                     case 0: {
                             if (cube%3!=2) returnVal=cube+1;
                             break;
                             }
                     case 1: {
                             if (cube%9<6) returnVal=cube+3;
                             break;
                             }
                     case 2: {
                             if (cube<18) returnVal=cube+9;
                             break;
                             }
                     }
                break;
                }
         case 1:{
                switch(dir){
                     case 0: {
                             if (cube%3!=0) returnVal=cube-1;
                             break;
                             }
                     case 1: {
                             if (cube%9>2) returnVal=cube-3;
                             break;
                             }
                     case 2: {
                             if (cube>8) returnVal=cube-9;
                             break;
                             }
                     }
                break;
                }
         }
     return returnVal;
     }
         

    /** Find the bounding box of this model */
    void findBB() {
	int corners;
      float point[]=new float[3];
      int tpoint[]=new int[3];
      point[0]=cube[0];
      point[1]=cube[1];
      point[2]=cube[2];
      mat[cubes[0]].transform(point,tpoint,1);
      
	xmin = tpoint[0]; xmax = xmin;
	ymin = tpoint[1]; ymax = ymin;
	zmin = tpoint[2]; zmax = zmin;
	for (int q = 1; q<8;q++) {
          point[0]=cube[q*3];
          point[1]=cube[q*3+1];
          point[2]=cube[q*3+2];
          mat[cubes[q]].transform(point,tpoint,1);
//          System.out.println("BoundingBox: "+q+" "+tpoint[0]+" "+tpoint[1]+" "+tpoint[2]);
	    if (tpoint[0] < xmin)
		xmin = tpoint[0];
	    if (tpoint[0] > xmax)
		xmax = tpoint[0];
	    if (tpoint[1] < ymin)
		ymin = tpoint[1];
	    if (tpoint[1] > ymax)
		ymax = tpoint[1];
	    if (tpoint[2] < zmin)
		zmin = tpoint[2];
	    if (tpoint[2] > zmax)
		zmax = tpoint[2];
	}
//	this.xmax = xmax;
//	this.xmin = xmin;
//	this.ymax = ymax;
//	this.ymin = ymin;
//	this.zmax = zmax;
//	this.zmin = zmin;
 //     System.out.print("Xmax "+this.xmax+" Xmin "+this.xmin+" ");
 //     System.out.print("Ymax "+this.ymax+" Ymin "+this.ymin+" ");
 //     System.out.print("Zmax "+this.zmax+" Zmin "+this.zmin+" ");
    }

   public int searchFace(int x, int y)
      {
      int face=-1;
      // System.out.println("In searchFace...");
      int counter;
      float v[]=new float[12];
      int v1[]=new int[12];
      double v2[]=new double[8];
      double sumangles=0.0,length;
      for (counter=0; counter<54;counter++)
        {
        if (tnormals[counter]>0)
          {
          for (int yy=0; yy<4;yy++)
            {
            for(int zz=0; zz<3; zz++)
               {
	      	v[yy*3+zz]=cube[faces[squares[counter+54]*4+yy]*3+zz];
               }
            }
          mat[squares[counter]].transform(v, v1, 4);
          for (int yy=0; yy<12; yy++)
             {
             v[yy]=(float)v1[yy];
             }
          overall.transform(v, v1, 4);
          for (int yy=0;yy<4;yy++)
               {
                v2[yy*2]=(double)(v1[yy*3]-x);  v2[yy*2+1]=(double)(v1[yy*3+1]-y);
                length=Math.sqrt(v2[yy*2]*v2[yy*2]+v2[yy*2+1]*v2[yy*2+1]);
                v2[yy*2]/=length;v2[yy*2+1]/=length;
               }
          sumangles=0.0;
          for (int yy=0;yy<4;yy++)
               {sumangles+=Math.acos(v2[yy*2]*v2[((yy+1)%4)*2]+v2[yy*2+1]*v2[((yy+1)%4)*2+1]);            }
   //            System.out.println("Face "+counter+" Angle "+sumangles);
                         
          if (Math.abs(sumangles-Math.PI*2.0)<0.000001) {face=counter; counter=54;}
          }}  
   // System.out.println("Returning "+face+" cube: "+squares[face]);
   return face; 
   }
}

/** An applet to put a 3D model into a page */
public class ThreeD extends Panel {
    Model3D md;
    boolean painted = true;
    float xfac;
    int prevx, prevy,face;
    float xtheta, ytheta;
    float scalefudge = 1;
    Matrix3D amat = new Matrix3D(), tmat = new Matrix3D();
    String mdname = null;
    String message = null;

    public void move(int a){
       return;
    }
    public void init() {
	// System.out.println("at init time, CM = "+getColorModel());
        mdname = "models/cube.obj";
	try {
	    scalefudge = 1; /*Float.valueOf(getParameter("scale")).floatValue();*/
	}catch(Exception e){};
	amat.yrot(20);
	amat.xrot(20);
	if (mdname == null)
	    mdname = "model.obj";
	resize(size().width <= 20 ? 400 : size().width,
	       size().height <= 20 ? 400 : size().height);
    }
    public void run(URL s) {
      // System.out.println("ThreeD: run");
	InputStream is = null;
	try {
	    Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
	/*    is = new URL(s, mdname).openStream();  */
	    is = s.openStream();
	    Model3D m = new Model3D (is);
	    md = m;
	    m.findBB();
	    float xw = m.xmax - m.xmin;
	    float yw = m.ymax - m.ymin;
	    float zw = m.zmax - m.zmin;
	    if (yw > xw)
		xw = yw;
	    if (zw > xw)
		xw = zw;
	    float f1 = 150f / xw;
	    float f2 = 150f / xw;
	    xfac = 0.55f * (f1 < f2 ? f1 : f2) * scalefudge;
	} catch(Exception e) {
	    md = null;
	    message = e.toString();
	}
	try {
	    if (is != null)
		is.close();
	} catch(Exception e) {
	}
	repaint();
    }
    
    public void stop() {
    }

	public Dimension preferredSize(){
return new Dimension(150,150);}

    public boolean mouseDown(Event e, int x, int y) {
      // System.out.println("In mouseDown:  X: "+x+" Y: "+y);
	prevx = x;
	prevy = y;
      face=md.searchFace(x,y);
   //   if (face != -1) md.cols[face]=(md.cols[face]+1)%6;
	return true;
    }
    public boolean mouseUp(Event e, int x, int y) {
	int face2;
      if(face!=23&&face!=10&&face!=26&&face!=27&&face!=30&&face!=43&&face!=-1){
	face2=md.searchFace(x,y);
          if (face!=face2&&face2!=-1) md.move(face,face2,this);
      }
    	prevx = x;
	prevy = y;
	return true;
    }
    public boolean mouseDrag(Event e, int x, int y) {
	tmat.unit();
      if(face==23||face==10||face==26||face==27||face==30||face==43){
	float xtheta = (y-prevy) * 360.0f / size().width;
	float ytheta = (x - prevx) * 360.0f / size().height;
	tmat.xrot(xtheta);
	tmat.yrot(ytheta);
	amat.mult(tmat);
	if (painted) {
	    painted = false;
	    repaint();
	}
      // System.out.println("MouseDrag: X "+x+" Y "+y+" prevx "+prevx+" prevy "+prevy);
      }
      
    	prevx = x;
	prevy = y;
	return true;
    }
    public void paint(Graphics g) {
//	System.out.println("ThreeD: paint");
	if (md != null) {
	    md.findBB();
          md.overall.unit();
	          md.overall.mult(amat);
	         md.overall.scale(2.5f);
	          md.overall.translate(size().width / 2, (size().height) / 2, 8);
	
	    md.transformed = false;
          md.paint(g);
//	    g.drawString("Copyright 1996 Rupert Brooks", 1, size().height-25);
//	    g.drawString("   Rubik's Cube V1.0 beta", 10, size().height-10);
	    setPainted();
	} else if (message != null) {
	    g.drawString("Bogus Dude! - Exploded in the hangar!", 3, size().height-50);
	    g.drawString("Hey! Its a beta version, right!", 10, size().height-40);
	}
    }
    private synchronized void setPainted() {
	painted = true;
	notifyAll();
    }
}
