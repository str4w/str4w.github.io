import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.JApplet;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 * @author Rupert
 */
class Utility
{
    static public String formatTime(long time_in)
    {
        long hours = time_in/3600000l;
        long min   = (time_in-hours*3600000l)/60000l;
        double seconds = (time_in - hours*3600000l - min*60000l)/1000.0;
        return String.format("%02d:%02d:%04.1f",hours,min,seconds);
    }

    static public long timeNow()
    {
        Calendar cal = new GregorianCalendar();
        //cal.setTimeZone(TimeZone.getDefault());

        long hour24 = cal.get(Calendar.HOUR_OF_DAY);  // 0..23
        long minutes = cal.get(Calendar.MINUTE);      // 0..59
        long seconds = cal.get(Calendar.SECOND);      // 0..59
        long milliseconds = cal.get(Calendar.MILLISECOND);      // 0..1000
        return ((((hour24 * 60) +minutes)*60) +seconds)*1000 +milliseconds;
    }
}

class BusRow extends JPanel
{
    BusRow(String p_title, Color p_alertColor, Color p_defaultColor, int p_largeFontSize, int p_smallFontSize, int p_times[])
    {
        m_alertColor = p_alertColor;
        m_defaultColor = p_defaultColor;
        m_largeFontSize = p_largeFontSize;
        m_smallFontSize = p_smallFontSize;
        
        m_title = new JLabel(p_title);
        m_first = new JLabel("--:--");
        m_second = new JLabel("--:--");
        m_title_2 = new JLabel("");
        m_first_2 = new JLabel("");
        m_second_2 = new JLabel("");
        m_times = p_times;
        m_title.setHorizontalTextPosition(JLabel.CENTER);
        m_title.setFont(new Font("Serif", Font.BOLD, p_largeFontSize));
        m_title.setForeground(m_defaultColor);
        m_first.setHorizontalTextPosition(JLabel.CENTER);
        m_first.setFont(new Font("Serif", Font.PLAIN, p_largeFontSize));
        m_first.setForeground(m_defaultColor);
        m_second.setHorizontalTextPosition(JLabel.CENTER);
        m_second.setFont(new Font("Serif", Font.PLAIN, p_largeFontSize));
        m_second.setForeground(m_defaultColor);

        m_title_2.setHorizontalTextPosition(JLabel.RIGHT);
        m_title_2.setFont(new Font("Serif", Font.BOLD, p_smallFontSize));
        m_title_2.setForeground(m_defaultColor);
        m_first_2.setHorizontalTextPosition(JLabel.RIGHT);
        m_first_2.setFont(new Font("Serif", Font.BOLD, p_smallFontSize));
        m_first_2.setForeground(m_defaultColor);
        m_second_2.setHorizontalTextPosition(JLabel.RIGHT);
        m_second_2.setFont(new Font("Serif", Font.BOLD, p_smallFontSize));
        m_second_2.setForeground(m_defaultColor);
        this.setLayout(new GridLayout(0,3) );
        this.add(m_title);
        this.add(m_first);
        this.add(m_second);
        this.add(new JLabel());
        this.add(m_first_2);
        this.add(m_second_2);
        this.updateValues();

    }
    public void updateValues()
    {
        long currentTime=Utility.timeNow();
        {
            long nexttime = m_times[0]*60000;
            long secondnexttime = nexttime;
            long next = nexttime - currentTime;
            if (next<0) next+=24*3600000;
            long secondnext = next+24*3600000;
            for (int i=1;i<m_times.length; ++i)
            {
                long delaytime = m_times[i]*60000;
                long delay = delaytime - currentTime;
                if (delay<0) delay+=24*3600000;
                if (delay<next)
                {
                    secondnexttime=nexttime;
                    secondnext=next;
                    nexttime=delaytime;
                    next=delay;
                }
                else if (delay<secondnext)
                {
                    secondnext=delay;
                    secondnexttime=delaytime;
                }
            }
            m_first.setText(Utility.formatTime(next));
            m_second.setText(Utility.formatTime(secondnext));
            m_first_2.setText("("+Utility.formatTime(nexttime)+")");
            m_second_2.setText("("+Utility.formatTime(secondnexttime)+")");
            if (next<5*60*1000)
            {
                m_first.setFont(new Font("Serif", Font.BOLD, m_largeFontSize));
                m_first.setForeground(m_alertColor);
                m_first_2.setForeground(m_alertColor);
            }
            else
            {
                m_first.setFont(new Font("Serif", Font.PLAIN, m_largeFontSize));
                m_first.setForeground(m_defaultColor);
                m_first_2.setForeground(m_defaultColor);
            }
        }
    }

    Color m_alertColor;
    Color m_defaultColor;
    int m_largeFontSize;
    int m_smallFontSize;

    int m_times[];
    JLabel m_title;
    JLabel m_first;
    JLabel m_second;
    JLabel m_title_2;
    JLabel m_first_2;
    JLabel m_second_2;
}

public class NextBus extends JApplet {

    // Interface components
    JPanel mainPanel;
    int largeFontSize;
    int smallFontSize;
    int clockFontSize;

    int route61_times[]={
       6 * 60 + 16,
       6 * 60 + 51,
       7 * 60 + 18,
       7 * 60 + 38,
       8 * 60 + 02,
       8 * 60 + 33,
       9 * 60 + 03,
       9 * 60 + 34,
       10 * 60 + 12,
       11 * 60 + 20,
       12 * 60 + 30,
       13 * 60 + 40,
       14 * 60 + 50,
       15 * 60 + 27,
       16 * 60 + 02,
       16 * 60 + 44,
       17 * 60 + 19,
       17 * 60 + 49,
       18 * 60 + 19,
       18 * 60 + 49,
       19 * 60 + 20,
       19 * 60 + 50,
       20 * 60 + 13,
       21 * 60 + 21,
       22 * 60 + 31,
       23 * 60 + 41,
       0 * 60 + 51
    };

    int route84_times[]={
       6 * 60 + 35,
       6 * 60 + 52,
       7 * 60 + 07,
       7 * 60 + 22,
       7 * 60 + 37,
       7 * 60 + 52,
       8 * 60 + 10,
       8 * 60 + 30,
       8 * 60 + 50,
       9 * 60 + 07,
       9 * 60 + 32,
       10 * 60 + 17,
       11 * 60 + 17,
       12 * 60 + 17,
       13 * 60 + 17,
       14 * 60 + 17,
       15 * 60 + 17,
       16 * 60 + 05,
       16 * 60 + 35,
       16 * 60 + 57,
       17 * 60 + 12,
       17 * 60 + 27,
       17 * 60 + 42,
       17 * 60 + 57,
       18 * 60 + 12,
       18 * 60 + 27,
       18 * 60 + 39,
       18 * 60 + 54,
       19 * 60 + 17,
       20 * 60 + 17,
       21 * 60 + 17,
       22 * 60 + 17,
       23 * 60 + 17,
       0 * 60 + 17,
       1 * 60 + 17
    };

    int route185_times[]={
       16 * 60 + 14,
       16 * 60 + 45,
       17 * 60 + 15,
       17 * 60 + 45,
       18 * 60 + 13
    };

    JLabel label_currentTime;    
    BusRow m_busRow0;
    BusRow m_busRow1;
    BusRow m_busRow2;

    Timer timer;

    //Called by init.
    protected void loadAppletParameters() {
        //Get the applet parameters.
        String lfs = getParameter("largeFontSize");
        largeFontSize = (lfs != null) ? Integer.valueOf(lfs).intValue() : 18;
        String cfs = getParameter("clockFontSize");
        clockFontSize = (cfs != null) ? Integer.valueOf(cfs).intValue() : 24;
        String sfs = getParameter("largeFontSize");
        smallFontSize = (sfs != null) ? Integer.valueOf(sfs).intValue() : 12;
    }

    private void createGUI() {

        //Create and set up the panel.
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        JPanel subPanel=new JPanel();
        subPanel.setLayout(new GridLayout(0, 3));
        
        JLabel l1 = new JLabel("   ROUTE   ");
        l1.setFont(new Font("Serif", Font.BOLD, largeFontSize));
        subPanel.add(l1);
        JLabel l2 = new JLabel("   NEXT    ");
        l2.setFont(new Font("Serif", Font.BOLD, largeFontSize));
        subPanel.add(l2);
        JLabel l3 = new JLabel("   AFTER   ");
        l3.setFont(new Font("Serif", Font.BOLD, largeFontSize));
        subPanel.add(l3);

        label_currentTime=new JLabel("----");
        label_currentTime.setHorizontalTextPosition(JLabel.CENTER);
        label_currentTime.setFont(new Font("Serif", Font.BOLD, clockFontSize));
        label_currentTime.setForeground(new Color(0x0000ff));

        m_busRow0 = new BusRow("61", Color.RED, Color.BLACK, largeFontSize, smallFontSize, route61_times);
        m_busRow1 = new BusRow("84", Color.RED, Color.BLACK, largeFontSize, smallFontSize, route84_times);
        m_busRow2 = new BusRow("185",Color.RED, Color.BLACK, largeFontSize, smallFontSize, route185_times);

        updateValues();
        mainPanel.add(label_currentTime);
        mainPanel.add(subPanel);
        mainPanel.add(m_busRow0);
        mainPanel.add(m_busRow1);
        mainPanel.add(m_busRow2);

        setContentPane(mainPanel);

    }
    public void updateValues()
    {
        long currentTime=Utility.timeNow();
        label_currentTime.setText(Utility.formatTime(currentTime));


        m_busRow0.updateValues();
        m_busRow1.updateValues();
        m_busRow2.updateValues();
    }

    private class RefreshTask extends TimerTask
    {
        public void run()  {  updateValues(); }
    }

    //Called when this applet is loaded into the browser.
    public void init() {
        loadAppletParameters();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) { }

        try {
           createGUI();
        } catch (Exception e) {
            System.err.println("createGUI didn't successfully complete");
        }
        // Set up and start the timer to refresh the  bus times
        RefreshTask refreshTask = new RefreshTask();
        timer = new Timer();
        timer.schedule(refreshTask, 0, 50);
  
    }

    public String getAppletInfo() {
        return "Title: NextBus, Dec 2009\n"
               + "Author: Rupert Brooks\n"
               + "Counts Down to the next bus times on some hardcoded routes";
    }

    public String[][] getParameterInfo() {
        String[][] info = {
            {"largeFontSize", "int", "the font size for the large times"},
            {"clockFontSize", "int", "the font size for the clock"},
            {"smallFontSize", "int", "the font size for the bus arrival times"}
        };
        return info;
    }


}
