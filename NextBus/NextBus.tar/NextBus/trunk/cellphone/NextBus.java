    // Sample adapted from http://developers.sun.com/mobility/midp/articles/wtoolkit/
    import javax.microedition.lcdui.*;
    import javax.microedition.midlet.*;
    import java.util.Timer;
    import java.util.TimerTask;
    import java.util.Calendar;
    import java.util.Date;
    /**
     * @author Rupert
     */
    class Utility
    {
        static public String formatInt(long in)
        {
           long tens = in/10l;
           long ones = in-tens*10l;
           return ""+tens+ones;
        }
        static public String formatDecimal(long in)
        {
           long hundreds = in/100l;
           long tens = (in-hundreds*100l)/10l;
           long ones = in-tens*10l-hundreds*100l;
           return "" + hundreds + tens;// + "." +ones;
        }
        static public String formatTime(long time_in)
        {
            long hours = time_in/3600000l;
            long min   = (time_in-hours*3600000l)/60000l;
            long seconds = (time_in - hours*3600000l - min*60000l)/100l;
            return (formatInt(hours) + ":" + formatInt(min) + ":" + formatDecimal(seconds) );
        }
    
        static public long timeNow()
        {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            //cal.setTimeZone(TimeZone.getDefault());
    
            long hour24 = cal.get(Calendar.HOUR_OF_DAY);  // 0..23
            long minutes = cal.get(Calendar.MINUTE);      // 0..59
            long seconds = cal.get(Calendar.SECOND);      // 0..59
            long milliseconds = cal.get(Calendar.MILLISECOND);      // 0..1000
            return ((((hour24 * 60) +minutes)*60) +seconds)*1000 +milliseconds;
        }
    }
class BusRow 
{
    BusRow( int p_times[], StringItem top, StringItem bottom) //Color p_alertColor, Color p_defaultColor, int p_largeFontSize, int p_smallFontSize, int p_times[])
    {
        //m_alertColor = p_alertColor;
        //m_defaultColor = p_defaultColor;
        //m_largeFontSize = p_largeFontSize;
        //m_smallFontSize = p_smallFontSize;
        m_top=top;
        m_bottom=bottom;
        m_times=p_times;
        
    }
    public void updateValues()
    {
        long currentTime=Utility.timeNow();
        {
            long nexttime = m_times[0]*60000;
            long secondnexttime = nexttime;
            long next = nexttime - currentTime;
            if (next<0) next+=24*3600000;
            long secondnext = next+24*3600000;
            for (int i=1;i<m_times.length; ++i)
            {
                long delaytime = m_times[i]*60000;
                long delay = delaytime - currentTime;
                if (delay<0) delay+=24*3600000;
                if (delay<next)
                {
                    secondnexttime=nexttime;
                    secondnext=next;
                    nexttime=delaytime;
                    next=delay;
                }
                else if (delay<secondnext)
                {
                    secondnext=delay;
                    secondnexttime=delaytime;
                }
            }
            m_top.setText( Utility.formatTime(next) + "  " + Utility.formatTime(secondnext));
            m_bottom.setText("("+Utility.formatTime(nexttime)+")("+Utility.formatTime(secondnexttime)+")");
/*            m_first.setText(Utility.formatTime(next));
            m_second.setText(Utility.formatTime(secondnext));
            m_first_2.setText("("+Utility.formatTime(nexttime)+")");
            m_second_2.setText("("+Utility.formatTime(secondnexttime)+")");
            if (next<5*60*1000)
            {
                m_first.setFont(new Font("Serif", Font.BOLD, m_largeFontSize));
                m_first.setForeground(m_alertColor);
                m_first_2.setForeground(m_alertColor);
            }
            else
            {
                m_first.setFont(new Font("Serif", Font.PLAIN, m_largeFontSize));
                m_first.setForeground(m_defaultColor);
                m_first_2.setForeground(m_defaultColor);
            }
*/
        }
    }

    //Color m_alertColor;
    //Color m_defaultColor;
    //int m_largeFontSize;
    //int m_smallFontSize;

    int m_times[];
    StringItem m_top,m_bottom;
    //JLabel m_title;
    //JLabel m_first;
    //JLabel m_second;
    //JLabel m_title_2;
    //JLabel m_first_2;
    //JLabel m_second_2;
}
    public class NextBus extends MIDlet implements CommandListener 
    {
    int route61_times[]={
       6 * 60 + 16,
       6 * 60 + 51,
       7 * 60 + 18,
       7 * 60 + 38,
       8 * 60 + 02,
       8 * 60 + 33,
       9 * 60 + 03,
       9 * 60 + 34,
       10 * 60 + 12,
       11 * 60 + 20,
       12 * 60 + 30,
       13 * 60 + 40,
       14 * 60 + 50,
       15 * 60 + 27,
       16 * 60 + 02,
       16 * 60 + 44,
       17 * 60 + 19,
       17 * 60 + 49,
       18 * 60 + 19,
       18 * 60 + 49,
       19 * 60 + 20,
       19 * 60 + 50,
       20 * 60 + 13,
       21 * 60 + 21,
       22 * 60 + 31,
       23 * 60 + 41,
       0 * 60 + 51
    };

    int route84_times[]={
       6 * 60 + 35,
       6 * 60 + 52,
       7 * 60 + 07,
       7 * 60 + 22,
       7 * 60 + 37,
       7 * 60 + 52,
       8 * 60 + 10,
       8 * 60 + 30,
       8 * 60 + 50,
       9 * 60 + 07,
       9 * 60 + 32,
       10 * 60 + 17,
       11 * 60 + 17,
       12 * 60 + 17,
       13 * 60 + 17,
       14 * 60 + 17,
       15 * 60 + 17,
       16 * 60 + 05,
       16 * 60 + 35,
       16 * 60 + 57,
       17 * 60 + 12,
       17 * 60 + 27,
       17 * 60 + 42,
       17 * 60 + 57,
       18 * 60 + 12,
       18 * 60 + 27,
       18 * 60 + 39,
       18 * 60 + 54,
       19 * 60 + 17,
       20 * 60 + 17,
       21 * 60 + 17,
       22 * 60 + 17,
       23 * 60 + 17,
       0 * 60 + 17,
       1 * 60 + 17
    };

    int route185_times[]={
       16 * 60 + 14,
       16 * 60 + 45,
       17 * 60 + 15,
       17 * 60 + 45,
       18 * 60 + 13
    };

       private Form mMainForm;
       private StringItem clock;
       BusRow B1,B2,B3;
       Timer timer;
       public NextBus() 
       {
           mMainForm = new Form("NextBus");
           clock = new StringItem("Time: ", "Hello, World!");
           mMainForm.append(clock);
           mMainForm.addCommand(new Command("Exit", Command.EXIT, 0));
           mMainForm.setCommandListener(this);
           {
              StringItem t1 = new StringItem(" 61 ", "---");
              StringItem t2 = new StringItem("    ", "---");
              mMainForm.append(t1);
              mMainForm.append(t2);
              B1=new BusRow( route61_times,t1,t2);
           }
           
           {
              StringItem t1 = new StringItem(" 84 ", "---");
              StringItem t2 = new StringItem("    ", "---");
              mMainForm.append(t1);
              mMainForm.append(t2);
              B2=new BusRow( route84_times,t1,t2);
           }
           {
              StringItem t1 = new StringItem("185 ", "---");
              StringItem t2 = new StringItem("    ", "---");
              mMainForm.append(t1);
              mMainForm.append(t2);
              B3=new BusRow( route185_times,t1,t2);
           }
           updateValues();
       }
     public void updateValues()
    {
        long currentTime=Utility.timeNow();
        clock.setText(Utility.formatTime(currentTime));
        B1.updateValues();
        B2.updateValues();
        B3.updateValues();

        //m_busRow0.updateValues();
        //m_busRow1.updateValues();
        //m_busRow2.updateValues();
    }
    private class RefreshTask extends TimerTask
    {
        public void run()  {  updateValues(); }
    }

      RefreshTask refreshTask;
      Display display;
       public void startApp() { 
        display=Display.getDisplay(this);
        display.setCurrent(mMainForm);
        // Set up and start the timer to refresh the stock quotes
        refreshTask = new RefreshTask();
        timer = new Timer();
        timer.schedule(refreshTask, 0, 1000);
   }
       public void pauseApp() {

}
       public void destroyApp(boolean unconditional) {

            synchronized (this) {
                timer.cancel();
}



}
       public void commandAction(Command c, Displayable s) { destroyApp(false); notifyDestroyed(); }
    }
